package usecases;

public class UpgradeTower {

	/*
	public void upgradeTower(MockTower tower) {
		// update player funds
		tower.getModifiablePlayerInfo().updateAvailableFunds(tower.getUpgradeCost());
		// update tower's upgrade level
		tower.upgrade();
	}
	*/
	
}
