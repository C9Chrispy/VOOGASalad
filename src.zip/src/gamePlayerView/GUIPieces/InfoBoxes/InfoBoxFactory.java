package gamePlayerView.GUIPieces.InfoBoxes;

public class InfoBoxFactory {

}
