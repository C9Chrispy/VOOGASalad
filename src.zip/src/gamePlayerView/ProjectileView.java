package gamePlayerView;

import engine.IObserver;

/**
 * @author Guhan Muruganandam
 */

@Deprecated
public class ProjectileView implements IObserver {

	@Override
	public void update(Object aChangedObject) {
		// TODO 
	}

	@Override
	public void remove(Object aRemovedObject) {
		// TODO Auto-generated method stub
		
	}

}
