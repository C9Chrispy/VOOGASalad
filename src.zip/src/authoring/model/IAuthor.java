package authoring.model;

public interface IAuthor {
	public void showError(String error);
}
