package authoring.view.tabs;

import javafx.scene.control.Button;

public interface ISubmittable {
	
	public Button setUpSubmitButton();

}
