package mainmenu.screens;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class LoadGameScreen extends AbstractLoadScreen {

	public LoadGameScreen(String title, String files) throws IOException {
		super(title, files);
	}

	@Override
	protected void start(String selectedGame) {
		// TODO Matt, fill in here
		
	}

	

}
