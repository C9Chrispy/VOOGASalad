package engine.model.resourcestore;

import java.util.List;

import authoring.model.EntityData;

public interface IEntityUpgradeStore {
	public List<EntityData> getBaseEntitesData();
}
