package engine.model.resourcestore;

public interface IVisitable {

}
