package engine.model.game_environment;

/**
 * Visitable objects can accept any entity object. They may be selective about 
 * placing an object
 * @author matthewfaw
 *
 */
public interface IVisitable {

}
