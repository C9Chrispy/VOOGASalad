package engine.model.components.viewable_interfaces;

import engine.IObservable;

public interface IViewableTargeting extends IViewable, IObservable<IViewableTargeting>{

}
