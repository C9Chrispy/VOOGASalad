package engine.model.components.viewable_interfaces;

public interface IViewableSell {

}
