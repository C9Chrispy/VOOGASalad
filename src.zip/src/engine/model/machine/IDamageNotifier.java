package engine.model.machine;

@Deprecated
public interface IDamageNotifier {
	public void notifyAboutDamageChange(double damageDealt);
}
