package engine.model.machine.enemy;

/**
 * Core interface for enemy behavior
 *
 */
@Deprecated
public interface IEnemy {
	
}
