package engine.model.machine.enemy;

@Deprecated
public class Enemy /*extends Machine*/ {
	/*
	private int myBounty;
	
	public Enemy(WeaponFactory armory, IModifiablePlayer owner, EnemyData data,
			Point initialPosition) {
		super(armory, owner, data, initialPosition);
		myBounty = data.getKillReward();
	}
	
	@Override
	protected int die() {
		//TODO: Delete self
		unregisterMyself();
		return myBounty;
	}
	@Override
	public Point getGoal() {
		//This is intended. (Contrast with projectile's getGoal() method.)
		return null;
	}
	*/
}