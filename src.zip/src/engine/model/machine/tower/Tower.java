package engine.model.machine.tower;

@Deprecated
public class Tower{ /*extends Machine implements IUpgradable {
	

	public Tower(WeaponFactory armory, IModifiablePlayer owner, TowerData data,
			Point initialPosition) {
		super(armory, owner, data, initialPosition);
	}
	
	@Override
	protected int die() {
		//TODO: Delete self
		unregisterMyself();
		return 0;
	}
	
	@Override
	public void upgrade(TowerData upgradeData) {
		super.upgrade(upgradeData);
	}
	
	@Override
	public Point getGoal() {
		//This is intended. (Contrast with projectile's getGoal() method.)
		return null;
	}
*/
}