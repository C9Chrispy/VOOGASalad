package utility;

public class Circle implements IShape {

	@Override
	public double getDistanceTo(Point p) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getDistanceTo(IShape s) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Point closestTo(Point p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Point closestTo(IShape s) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean contains(Point p) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean contains(IShape s) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean overlaps(IShape s) {
		// TODO Auto-generated method stub
		return false;
	}

}
